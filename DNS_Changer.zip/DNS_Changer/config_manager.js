const fs = require('fs').promises;

const defaultConfig = {
    'Shecan': ['178.22.122.100', '185.51.200.2'],
    'Begzar': ['185.55.226.26', '185.55.225.25'],
    'Shatel': ['85.15.1.14', '85.15.1.15'],
    'Electro': ['78.157.42.101', '78.157.42.100'],
    'Radar': ['10.202.10.10', '10.202.10.11'],
    '403': ['10.202.10.202', '10.202.10.102']
};

async function loadConfig(filePath = 'dns_config.json') {
    try {
        const data = await fs.readFile(filePath, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        if (err.code === 'ENOENT') return defaultConfig;
        throw err;
    }
}

async function saveConfig(config, filePath = 'dns_config.json') {
    await fs.writeFile(filePath, JSON.stringify(config, null, 4), 'utf8');
}

module.exports = { loadConfig, saveConfig };
