const readline = require('readline');
const { loadConfig, saveConfig } = require('./config_manager');
const { getActiveAdapter, setDns } = require('./dns_manager');

async function checkAdminRights() {
  
    console.log('Please ensure that you run this program with administrative privileges.');
}

async function listConfigs() {
    const config = await loadConfig();
    console.log("Available DNS configurations:");
    return Object.keys(config).map((name, index) => {
        const [primary, secondary] = config[name];
        console.log(`${index + 1}. ${name}: ${primary}, ${secondary}`);
        return name;
    });
}

async function getDnsDetails() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) => {
        rl.question('Enter DNS name: ', (name) => {
            rl.question('Enter Preferred DNS: ', (preferred) => {
                rl.question('Enter Alternate DNS: ', (alternate) => {
                    rl.close();
                    resolve({ name, preferred, alternate });
                });
            });
        });
    });
}

async function confirmDnsDetails(details) {
    console.log(`DNS Name: ${details.name}`);
    console.log(`Preferred DNS: ${details.preferred}`);
    console.log(`Alternate DNS: ${details.alternate}`);
    
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) => {
        rl.question('Is this correct? (y/n): ', (answer) => {
            rl.close();
            resolve(answer.toLowerCase() === 'y');
        });
    });
}

async function addDnsConfig() {
    const details = await getDnsDetails();
    const isConfirmed = await confirmDnsDetails(details);

    if (isConfirmed) {
        const config = await loadConfig();
        config[details.name] = [details.preferred, details.alternate];
        await saveConfig(config);
        console.log('DNS configuration added successfully.');
    } else {
        console.log('DNS configuration not added. Please try again.');
    }
}

async function updateDnsSettings(choice, configNames) {
    const adapter = await getActiveAdapter();
    if (!adapter) {
        console.error("No active network adapter found");
        return;
    }

    const config = await loadConfig();
    const selectedConfig = configNames[choice - 1];
    const [primary, secondary] = config[selectedConfig];
    console.log(`DNS set to ${primary} and ${secondary}\n${await setDns(adapter, primary, secondary)}`);
}

async function startInteractiveMode() {
    await checkAdminRights();

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const configNames = await listConfigs();

    rl.question('Select a DNS configuration by number or type "add" to add a new configuration: ', async (answer) => {
        rl.close(); // Ensure readline is properly closed before proceeding

        if (answer.toLowerCase() === 'add') {
            await addDnsConfig();
            startInteractiveMode(); // Restart to reflect changes
        } else {
            const choice = parseInt(answer, 10);
            if (choice >= 1 && choice <= configNames.length) {
                await updateDnsSettings(choice, configNames);
            } else {
                console.log('Invalid choice, please run the program again.');
            }
        }
    });
}

startInteractiveMode();
