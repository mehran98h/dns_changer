const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);

async function runCommand(cmd) {
    try {
        const { stdout, stderr } = await execAsync(cmd);
        if (stderr) throw new Error(stderr);
        return stdout.trim();
    } catch (err) {
        return err.message;
    }
}

async function getActiveAdapter() {
    const output = await runCommand('wmic nic where "NetEnabled=true" get NetConnectionID /value');
    const match = output.match(/NetConnectionID=(.+)/);
    return match ? match[1].trim() : null;
}

async function setDns(adapter, primary, secondary) {
    const result1 = await runCommand(`netsh interface ip set dns name="${adapter}" static ${primary}`);
    const result2 = await runCommand(`netsh interface ip add dns name="${adapter}" ${secondary} index=2`);
    return `${result1}\n${result2}`;
}

async function unsetDns(adapter) {
    return await runCommand(`netsh interface ip set dns name="${adapter}" dhcp`);
}

async function asyncPingDns(dns, callback) {
    try {
        const { stdout } = await execAsync(`ping -n 1 ${dns}`);
        const latencyMatch = stdout.match(/time=(\d+)ms/);
        callback(latencyMatch ? parseInt(latencyMatch[1], 10) : null);
    } catch (error) {
        console.error('Ping error:', error);
        callback(null);
    }
}

module.exports = {
    getActiveAdapter,
    setDns,
    unsetDns,
    asyncPingDns
};
